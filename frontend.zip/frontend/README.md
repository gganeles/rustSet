# SolidJS Frontend

Install and run:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 in your browser. The app connects to `ws://127.0.0.1:3030/ws` by default.
